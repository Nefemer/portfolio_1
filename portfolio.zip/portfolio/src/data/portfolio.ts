// src/data/portfolio.ts
// ✏️ Edita este archivo con tu información personal

export interface Project {
  title: string;
  description: string;
  tags: string[];
  url?: string;
  github?: string;
}

export interface ContactLink {
  label: string;
  url: string;
  icon: 'github' | 'linkedin' | 'email' | 'twitter';
}

export const personal = {
  name: 'Tu Nombre',
  role: 'Desarrollador Web',
  bio: 'Apasionado por construir interfaces limpias y código bien estructurado. Especializado en TypeScript y tecnologías web modernas.',
  available: true, // cambia a false si no buscas trabajo
  cvUrl: '/cv.pdf', // coloca tu CV en la carpeta public/
};

export const technologies: string[] = [
  'TypeScript',
  'Astro',
  'JavaScript',
  'HTML / CSS',
  'React',
  'Node.js',
  'Git',
  'SQL',
];

export const projects: Project[] = [
  {
    title: 'Proyecto Alpha',
    description: 'Descripción de lo que hace este proyecto y qué tecnologías usaste.',
    tags: ['TypeScript', 'Astro'],
    github: 'https://github.com/tu-usuario/proyecto-alpha',
    url: 'https://proyecto-alpha.vercel.app',
  },
  {
    title: 'Proyecto Beta',
    description: 'Descripción de lo que hace este proyecto y qué tecnologías usaste.',
    tags: ['Node.js', 'SQL'],
    github: 'https://github.com/tu-usuario/proyecto-beta',
  },
  {
    title: 'Proyecto Gamma',
    description: 'Descripción de lo que hace este proyecto y qué tecnologías usaste.',
    tags: ['React', 'TypeScript'],
    github: 'https://github.com/tu-usuario/proyecto-gamma',
    url: 'https://proyecto-gamma.netlify.app',
  },
];

export const contact: ContactLink[] = [
  {
    label: 'GitHub',
    url: 'https://github.com/tu-usuario',
    icon: 'github',
  },
  {
    label: 'LinkedIn',
    url: 'https://linkedin.com/in/tu-usuario',
    icon: 'linkedin',
  },
  {
    label: 'correo@email.com',
    url: 'mailto:correo@email.com',
    icon: 'email',
  },
];
